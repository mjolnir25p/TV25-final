# TV25 Android v3

Versão de teste para Android/B2 Pro.

- Corrige o arranque: `MainActivity.kt` estava vazio na versão anterior.
- WebView com JavaScript, DOM storage, mixed content, ficheiros e fullscreen.
- Ícone TV25 incluído.
- Mantém a interface TV25 v2 em `assets/index.html`.
